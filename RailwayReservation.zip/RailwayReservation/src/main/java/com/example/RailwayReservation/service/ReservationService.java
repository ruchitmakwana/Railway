package com.example.RailwayReservation.service;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.RailwayReservation.bean.passenger;


public interface ReservationService extends MongoRepository<passenger,String>
{

}
