package com.example.RailwayReservation.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.RailwayReservation.bean.passenger;

@RestController
public class ReservationServiceImpl
{
	//insertion of data
	@Autowired 
	ReservationService rService;
	
	@PostMapping("/insert")
	public String insertPassenger(@RequestBody passenger p)
	{
		rService.save(p);
		return "Success";
	}
	
	//displaying data by PRNno
	@GetMapping(value= "/ret/{pnrno}")//,produces=MediaType.APPLICATION_JSON_VALUE)
	public Optional<passenger> displayPassengerById(@PathVariable("pnrno") String pnrno)
	{
		return rService.findById(pnrno);
	}
}
